import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { IProduct } from './product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
product: IProduct[]
  constructor(private service : CartService) { }

  ngOnInit() {
    
    this.service.getCart().subscribe(data=>this.product=data);
  }

}
