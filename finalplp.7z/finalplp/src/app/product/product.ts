export interface IProduct
{
    productId:number;
    productName:string;
    price:number; 
}