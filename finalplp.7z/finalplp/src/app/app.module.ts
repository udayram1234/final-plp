import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AddcartComponent } from './addcart/addcart.component';
import { Route, RouterModule } from '@angular/router';
import { ProductComponent } from './product/product.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { PaymentComponent } from './payment/payment.component';
const routes:Route[]=[{
  path:'addcart',
  component:AddcartComponent
  },
{
  path:'produc',
  component:ProductComponent
},
{
  path:'pay',
  component:PaymentComponent
},
{
  path:'home',
  component:HomeComponent
}
];
@NgModule({
  declarations: [
    AppComponent,
    AddcartComponent,
    ProductComponent,
    HomeComponent,
    PaymentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,RouterModule.forRoot(routes),HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
