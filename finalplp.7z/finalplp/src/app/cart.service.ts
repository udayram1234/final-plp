import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { ICart } from './addcart/addcart';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  url:string="http://localhost:8184/users";
url1:string="http://localhost:8184/buy"; 
  constructor( private http : HttpClient) { }

  getCart() : Observable<ICart []>{
    return this.http.get<ICart []>(this.url);    
      }
    

      deleteProduct(productId:number):Observable<any>{
 

        return this.http.delete(`${this.url1}/${productId}`); 
       
       
       
        }
      
}
