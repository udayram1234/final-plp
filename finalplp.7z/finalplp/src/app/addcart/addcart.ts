export interface ICart{
    productId:number;
    productName:string;
    price:number;
}