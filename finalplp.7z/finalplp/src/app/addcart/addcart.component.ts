import { Component, OnInit } from '@angular/core';
import { ICart } from './addcart';
import { CartService } from '../cart.service';
import { BuyService } from '../buy.service';

@Component({
  selector: 'app-addcart',
  templateUrl: './addcart.component.html',
  styleUrls: ['./addcart.component.css']
})
export class AddcartComponent implements OnInit {
  imageUrl="../assets/cart.jpg";
  cart:ICart[]
  quantity=7;
  ProductId:number;
  ProductName:string;
  price:number;
  
  constructor(private service : CartService ) { }
  

  ngOnInit() {
    this.service.getCart().subscribe(data=>this.cart=data);
  }
/*   delete(cart : ICart){
    let arr=this.cart.filter(p=>p.productId=cart.productId);
  this.cart=arr;
} */
delet(cart : ICart){
  let arr1=this.cart.filter(p=>p.productId!=cart.productId);
this.cart=arr1;
}

  delete(cart:ICart)

 {

 let arr=this.cart.filter(p=>p.productId=cart.productId);

 this.cart=arr;

 this.service.deleteProduct(cart.productId).subscribe(data => {console.log(data)})

 }
 quant(quantity:number)
 {
if(this.quantity>7){
this.quantity=this.quantity-1;
 }
 else
 {
   alert("out of stock");
 }
}
}