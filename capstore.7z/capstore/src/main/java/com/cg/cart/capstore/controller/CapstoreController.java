package com.cg.cart.capstore.controller;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cart.capstore.entity.Capstore;
import com.cg.cart.capstore.service.ICapstore;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CapstoreController {
	
	

	
	@Autowired
	ICapstore iCapstore;

	
	@RequestMapping(value="/addcart/{productName}/{price}", method = RequestMethod.POST,headers="Accept=application/json")
	public int  addToCart(@PathVariable String productName,@PathVariable int price) {
		Capstore cap=new Capstore();
		Random rand = new Random();
		int id = rand.nextInt(900000000) + 1000000000;
		cap.setProductId(id);
		cap.setProductName(productName);
		cap.setPrice(price);
	
	
//	String res="Added Successfully to Cart  : "+cap.getProductId();

		return iCapstore.addToCart(cap);
		
		
	}
	
	@RequestMapping(value="/buy/{productId}", method = RequestMethod.DELETE,headers="Accept=application/json")
	public String buyProduct(@PathVariable int productId)
	{
		Capstore cap=new Capstore();
		cap= iCapstore.buyProduct(productId);
		String res="Successfully placed the order:"+cap.getProductId();

		
		 return res;
	}
	@GetMapping("/users")

    public List<Capstore> getUsers() {

        return (List<Capstore>) iCapstore.findAll();

    }
}
