package com.cg.cart.capstore.entity;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity(name="cappy")
public class Capstore  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @Column(name="Id")
	private int productId;
	
	@Column(name="PRODUCT_NAME")
	private String productName;
	
	@Column(name="PRICE")
	private int price;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	/*public Capstore() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Capstore(String productName, int price) {
		super();
		this.productName = productName;
		this.price = price;
	}*/
	@Override
	public String toString() {
		return "Capstore [productId=" + productId + ", productName=" + productName + ", price=" + price + "]";
	}
	

	
	
	
	
}
