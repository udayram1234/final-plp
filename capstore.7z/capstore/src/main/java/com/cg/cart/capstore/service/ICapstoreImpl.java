package com.cg.cart.capstore.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cart.capstore.dao.CapstoreRepository;
import com.cg.cart.capstore.entity.Capstore;

@Service
public class ICapstoreImpl implements ICapstore{
 
	@Autowired
	CapstoreRepository capstoreRepository;
	
	Capstore cap=new Capstore();
	
	@Override
	public int addToCart(Capstore capstore) {
		// TODO Auto-generated method stub
		
	  capstoreRepository.save(capstore);
	  return capstore.getProductId();
	}

	@Override
	public Capstore buyProduct(int productId) {
		// TODO Auto-generated method stub
		cap.setProductId(productId);
	capstoreRepository.delete(cap);
		return cap;
	}

	@Override
	public List<Capstore> findAll() {
		// TODO Auto-generated method stub
		return capstoreRepository.findAll();
	}
	
}
