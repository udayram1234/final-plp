package com.cg.cart.capstore.service;

import java.util.List;

import com.cg.cart.capstore.entity.Capstore;

public interface ICapstore {

	public int addToCart(Capstore capstore);
	
	public Capstore buyProduct(int productId);
	public List<Capstore> findAll();
	
}
