package com.cg.cart.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.cart.capstore.entity.Capstore;


@Repository
public interface CapstoreRepository  extends JpaRepository<Capstore , Integer>  {

}
